var searchData=
[
  ['queryrequest',['QueryRequest',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1FreebusyResource_1_1QueryRequest.html',1,'Google::Apis::Calendar::v3::FreebusyResource']]],
  ['quickaddrequest',['QuickAddRequest',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1EventsResource_1_1QuickAddRequest.html',1,'Google::Apis::Calendar::v3::EventsResource']]]
];
