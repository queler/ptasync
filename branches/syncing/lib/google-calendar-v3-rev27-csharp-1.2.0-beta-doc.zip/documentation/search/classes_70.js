var searchData=
[
  ['patchrequest',['PatchRequest',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1CalendarsResource_1_1PatchRequest.html',1,'Google::Apis::Calendar::v3::CalendarsResource']]],
  ['patchrequest',['PatchRequest',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1CalendarListResource_1_1PatchRequest.html',1,'Google::Apis::Calendar::v3::CalendarListResource']]],
  ['patchrequest',['PatchRequest',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1AclResource_1_1PatchRequest.html',1,'Google::Apis::Calendar::v3::AclResource']]],
  ['patchrequest',['PatchRequest',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1EventsResource_1_1PatchRequest.html',1,'Google::Apis::Calendar::v3::EventsResource']]],
  ['preferencesdata',['PreferencesData',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1Data_1_1Event_1_1GadgetData_1_1PreferencesData.html',1,'Google::Apis::Calendar::v3::Data::Event::GadgetData']]],
  ['privatedata',['PrivateData',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1Data_1_1Event_1_1ExtendedPropertiesData_1_1PrivateData.html',1,'Google::Apis::Calendar::v3::Data::Event::ExtendedPropertiesData']]]
];
